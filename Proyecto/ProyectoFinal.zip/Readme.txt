#Integrantes 
#---------------------------------------------------
# * Dayana Valentina Gonzalez Vargas
# * Luna Gabriela Duran Perez
# * Emanuel Naval Oviedo
#-----------------------------------------------------
Acceso a nuestros resultados

Se debe acceder al siguiente link https://mybuckesito.s3.amazonaws.com/out/resultados.html donde se podra 
visualizar los resultados esperados que se encuentran almacenados en un bucket de S3.

Se encontran con dos tablas donde la primera tabla tendra la lista de twets con la categoria de ciberacoso, su 
etiqueta asociada y la predicción. En la segunda tabla que se encuentra al final encontrara las metricas que se 
utilizaron para evaluar el modelo como Accuracy, f1_score y Hamming Loss con su respectivo puntaje.
